create extension if not exists pgcrypto;

create table if not exists game_balances (
  user_id uuid not null,
  game_type text not null,
  balance numeric not null default 0,
  primary key (user_id, game_type)
);

create table if not exists game_results (
  id uuid default gen_random_uuid(),
  game_type text not null,
  type_id integer not null,
  period_id text not null,
  result text not null,
  created_at timestamptz not null default now(),
  settled_at timestamptz,
  primary key (id),
  unique (game_type, type_id, period_id)
);

create table if not exists game_bets (
  id uuid default gen_random_uuid(),
  user_id uuid not null,
  game_type text not null,
  type_id integer not null,
  period_id text not null,
  bet_type text not null,
  bet_value text not null,
  amount numeric not null,
  status text not null default 'pending',
  win_amount numeric not null default 0,
  created_at timestamptz not null default now(),
  primary key (id)
);
