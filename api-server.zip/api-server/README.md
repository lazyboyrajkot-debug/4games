# API Server

Backend for Jalwa games (Wingo, K3, 5D). Supabase-backed.

## Environment variables

```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
PORT=8080
```

If Supabase credentials are not provided, the server runs in **demo mode** with in-memory storage and accepts any token.

## Run

```bash
pnpm install
pnpm run build
PORT=8080 node dist/index.mjs
```

## API endpoints

- `GET /api/healthz`
- `GET /api/games/:gameType/period?typeId=`
- `GET /api/games/:gameType/results?typeId=&limit=`
- `GET /api/games/:gameType/my-bets?typeId=`
- `POST /api/games/:gameType/bet` — body `{ typeId, betType, betValue, amount }`
- `PUT /api/games/:gameType/settle?typeId=` — manually settle current period

All `/api/games/*` endpoints require `Authorization: Bearer <token>`.

## Supabase schema

Run `supabase/schema.sql` in your Supabase SQL editor.

Tables:

- `game_balances` — per-user balance per game
- `game_results` — period results per game/type
- `game_bets` — user bets with status and win amount
