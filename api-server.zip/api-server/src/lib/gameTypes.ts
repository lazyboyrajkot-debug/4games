import crypto from "node:crypto";

export type GameType = "wingo" | "k3" | "fiveD";

const intervals: Record<GameType, Record<number, number>> = {
  wingo: { 1: 60, 2: 180, 3: 300, 4: 600 },
  k3: { 9: 60, 10: 180, 11: 300 },
  fiveD: { 13: 60, 14: 180, 15: 300 },
};

export function getIntervalSeconds(gameType: string, typeId: number) {
  const key = gameType as GameType;
  return intervals[key]?.[typeId] ?? 60;
}

export function currentPeriod(gameType: string, typeId: number) {
  const totalSeconds = getIntervalSeconds(gameType, typeId);
  const now = Math.floor(Date.now() / 1000);
  const slot = Math.floor(now / totalSeconds);
  const periodId = `${gameType}-${typeId}-${slot}`;
  const secondsLeft = totalSeconds - (now % totalSeconds);
  return { periodId, secondsLeft, totalSeconds };
}

function hashNumber(periodId: string, offset: number, max: number) {
  const hash = crypto
    .createHash("sha256")
    .update(`${periodId}:offset-${offset}:wingo-secret`)
    .digest("hex");
  return Number.parseInt(hash.slice(0, 8), 16) % max;
}

export function rawResult(gameType: GameType, periodId: string) {
  if (gameType === "wingo") {
    return String(hashNumber(periodId, 0, 10));
  }
  if (gameType === "k3") {
    return [1, 2, 3].map((i) => 1 + hashNumber(periodId, i, 6)).join(",");
  }
  if (gameType === "fiveD") {
    return Array.from({ length: 5 }, (_, i) => hashNumber(periodId, i, 10)).join("");
  }
  return String(hashNumber(periodId, 0, 10));
}

export function wingoSize(number: number) {
  return number >= 5 ? "big" : "small";
}

export function k3Size(sum: number) {
  if (sum >= 11 && sum <= 17) return "big";
  if (sum >= 4 && sum <= 10) return "small";
  return "---";
}

export function fiveDSize(digit: number) {
  return digit >= 5 ? "big" : "small";
}

export type FormattedResult = {
  periodId: string;
  createdAt?: string;
  number?: string;
  size?: string;
  result?: string;
  sum?: number;
};

export function formatResult(gameType: GameType, result: string): FormattedResult {
  if (gameType === "wingo") {
    const number = Number(result);
    return {
      periodId: "",
      number: result,
      size: wingoSize(number),
    };
  }
  if (gameType === "k3") {
    const nums = result.split(",").map((n) => Number(n));
    const sum = nums.reduce((a, b) => a + b, 0);
    return {
      periodId: "",
      result,
      sum,
      size: k3Size(sum),
    };
  }
  if (gameType === "fiveD") {
    return {
      periodId: "",
      result,
    };
  }
  return { periodId: "", result };
}

export function evaluateBet(
  gameType: GameType,
  betType: string,
  betValue: string,
  result: string,
): { won: boolean; multiplier: number } {
  const normalizedValue = betValue.toLowerCase().trim();
  let won = false;
  let multiplier = 0;

  if (gameType === "wingo") {
    const number = Number(result);
    const size = wingoSize(number);
    const isViolet = number === 0 || number === 5;

    if (betType === "number") {
      won = String(number) === normalizedValue;
      multiplier = won ? 9 : 0;
    } else if (betType === "color") {
      if (normalizedValue === "violet") {
        won = isViolet;
        multiplier = won ? 4.5 : 0;
      } else if (normalizedValue === "red") {
        won = [2, 4, 6, 8].includes(number) || (isViolet && false);
        won = [2, 4, 6, 8].includes(number);
        multiplier = won ? 2 : 0;
      } else if (normalizedValue === "green") {
        won = [1, 3, 7, 9].includes(number) || (isViolet && false);
        won = [1, 3, 7, 9].includes(number);
        multiplier = won ? 2 : 0;
      }
    } else if (betType === "size") {
      won = size === normalizedValue;
      multiplier = won ? 2 : 0;
    }
  } else if (gameType === "k3") {
    const nums = result.split(",").map((n) => Number(n));
    const sum = nums.reduce((a, b) => a + b, 0);
    const size = k3Size(sum);
    const parity = sum % 2 === 0 ? "even" : "odd";

    if (betType === "sum") {
      won = String(sum) === normalizedValue;
      if (won) multiplier = sum === 3 || sum === 18 ? 200 : sum === 4 || sum === 17 ? 60 : 10;
    } else if (betType === "size") {
      won = size.toLowerCase() === normalizedValue;
      multiplier = won ? 2 : 0;
    } else if (betType === "parity") {
      won = parity === normalizedValue;
      multiplier = won ? 2 : 0;
    }
  } else if (gameType === "fiveD") {
    const chars = result.split("");
    const positionMatch = betType.match(/^position_([a-e])_?(size|parity)?$/);
    if (positionMatch) {
      const posIndex = positionMatch[1].charCodeAt(0) - 97; // a=0, b=1, ...
      const digit = Number(chars[posIndex]);
      const size = fiveDSize(digit);
      const parity = digit % 2 === 0 ? "even" : "odd";
      const modifier = positionMatch[2];

      if (modifier === "size") {
        won = size === normalizedValue;
        multiplier = won ? 2 : 0;
      } else if (modifier === "parity") {
        won = parity === normalizedValue;
        multiplier = won ? 2 : 0;
      } else {
        won = String(digit) === normalizedValue;
        multiplier = won ? 9 : 0;
      }
    }
  }

  return { won, multiplier };
}
