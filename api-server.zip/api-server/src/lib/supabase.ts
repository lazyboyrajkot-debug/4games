import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env["SUPABASE_URL"];
const supabaseAnonKey = process.env["SUPABASE_ANON_KEY"];

const DEMO_USER = { id: "demo-user", email: "demo@example.com" };

function buildMockClient() {
  const storage: Record<string, any[]> = {};
  const getTable = (name: string) => (storage[name] = storage[name] || []);

  const chain = (table: string) => {
    let filters: Record<string, any> = {};
    let orderField = "created_at";
    let orderAsc = false;
    let limitValue = 100;

    const select = () => chain(table);
    const eq = (field: string, value: any) => {
      filters[field] = value;
      return chain(table);
    };
    const order = (field: string, { ascending }: { ascending: boolean }) => {
      orderField = field;
      orderAsc = ascending;
      return chain(table);
    };
    const limit = (n: number) => {
      limitValue = n;
      return chain(table);
    };

    const maybeSingle = async () => {
      const rows = getTable(table).filter((r) =>
        Object.entries(filters).every(([k, v]) => r[k] === v),
      );
      return { data: rows[0] ?? null, error: null };
    };

    const executeQuery = async () => {
      let rows = getTable(table).filter((r) =>
        Object.entries(filters).every(([k, v]) => r[k] === v),
      );
      rows.sort((a: any, b: any) => {
        const av = a[orderField] ?? "";
        const bv = b[orderField] ?? "";
        return orderAsc ? (av < bv ? -1 : 1) : av > bv ? -1 : 1;
      });
      rows = rows.slice(0, limitValue);
      return { data: rows, error: null };
    };

    const insert = (rows: any | any[]) => {
      const list = Array.isArray(rows) ? rows : [rows];
      const created = list.map((row) => ({ ...row, id: crypto.randomUUID(), created_at: new Date().toISOString() }));
      getTable(table).push(...created);
      return {
        select: () => ({
          single: async () => ({ data: created[0], error: null }),
        }),
      };
    };

    const upsert = (row: any) => {
      const rows = getTable(table);
      const idx = rows.findIndex((r) =>
        Object.entries(row).every(([k, v]) => k === "balance" || r[k] === v),
      );
      if (idx >= 0) rows[idx] = { ...rows[idx], ...row };
      else rows.push({ ...row, id: crypto.randomUUID(), created_at: new Date().toISOString() });
      return { error: null };
    };

    const update = (changes: any) => {
      const rows = getTable(table);
      const target = rows.filter((r) =>
        Object.entries(filters).every(([k, v]) => r[k] === v),
      );
      target.forEach((r) => Object.assign(r, changes));
      return { error: null };
    };

    return {
      select,
      eq,
      order,
      limit,
      maybeSingle,
      insert,
      upsert,
      update,
      then: executeQuery,
    };
  };

  return {
    from: (table: string) => chain(table),
    auth: {
      getUser: async () => ({ data: { user: DEMO_USER }, error: null }),
    },
  } as any;
}

export const supabase =
  supabaseUrl && supabaseAnonKey
    ? createClient(supabaseUrl, supabaseAnonKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
      })
    : buildMockClient();

export const isDemoMode = !supabaseUrl || !supabaseAnonKey;
