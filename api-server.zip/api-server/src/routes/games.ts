import { Router, type IRouter } from "express";
import {
  currentPeriod,
  rawResult,
  formatResult,
  evaluateBet,
  type GameType,
} from "../lib/gameTypes";
import { supabase } from "../lib/supabase";

const router: IRouter = Router();

function parseTypeId(value: unknown) {
  const id = Number(value);
  return Number.isInteger(id) ? id : null;
}

function toCamelCase(row: Record<string, any>): Record<string, any> {
  const out: Record<string, any> = {};
  for (const key of Object.keys(row)) {
    const camel = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
    out[camel] = row[key];
  }
  return out;
}

function demoResults(gameType: GameType, typeId: number, limit: number) {
  const results = [] as Array<Record<string, any>>;
  const period = currentPeriod(gameType, typeId);
  const totalSeconds = period.totalSeconds;
  const now = Math.floor(Date.now() / 1000);
  const currentSlot = Math.floor(now / totalSeconds);

  for (let i = 0; i < limit; i += 1) {
    const slot = currentSlot - i;
    const periodId = `${gameType}-${typeId}-${slot}`;
    const result = rawResult(gameType, periodId);
    const formatted = formatResult(gameType, result);
    formatted.periodId = periodId;
    formatted.createdAt = new Date(slot * totalSeconds * 1000).toISOString();
    results.push(formatted);
  }

  return results;
}

router.get("/:gameType/period", (req, res): void => {
  const typeId = parseTypeId(req.query["typeId"]);
  if (typeId == null) {
    res.status(400).json({ error: "Invalid typeId" });
    return;
  }
  res.json(currentPeriod(req.params.gameType, typeId));
});

router.get("/:gameType/results", async (req, res): Promise<void> => {
  const typeId = parseTypeId(req.query["typeId"]);
  const limit = Math.min(Number(req.query["limit"] ?? 20) || 20, 100);
  if (typeId == null) {
    res.status(400).json({ error: "Invalid typeId" });
    return;
  }
  const gameType = req.params.gameType as GameType;

  const { data, error } = await supabase
    .from("game_results")
    .select("period_id,result,created_at")
    .eq("game_type", gameType)
    .eq("type_id", typeId)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (!error && data && data.length > 0) {
    const formatted = data.map((row: { period_id: string; result: string; created_at: string }) => {
      const result = formatResult(gameType, row.result);
      result.periodId = row.period_id;
      result.createdAt = row.created_at;
      return result;
    });
    res.json({ data: formatted });
    return;
  }

  res.json({ data: demoResults(gameType, typeId, limit) });
});

router.get("/:gameType/my-bets", async (req, res): Promise<void> => {
  const typeId = parseTypeId(req.query["typeId"]);
  if (typeId == null) {
    res.status(400).json({ error: "Invalid typeId" });
    return;
  }
  const user = req.user;
  if (!user) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { data, error } = await supabase
    .from("game_bets")
    .select("*")
    .eq("user_id", user.id)
    .eq("game_type", req.params.gameType)
    .eq("type_id", typeId)
    .order("created_at", { ascending: false });

  if (error) {
    res.status(500).json({ error: error.message });
    return;
  }
  res.json({ data: (data ?? []).map(toCamelCase) });
});

router.post("/:gameType/bet", async (req, res): Promise<void> => {
  const user = req.user;
  if (!user) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const gameType = req.params.gameType as GameType;
  const { typeId, betType, betValue, amount } = req.body ?? {};
  const parsedTypeId = parseTypeId(typeId);
  const betAmount = Number(amount);
  if (parsedTypeId == null || !betType || betValue == null || !Number.isFinite(betAmount) || betAmount <= 0) {
    res.status(400).json({ error: "Invalid bet payload" });
    return;
  }

  const { data: balanceRow } = await supabase
    .from("game_balances")
    .select("balance")
    .eq("user_id", user.id)
    .eq("game_type", gameType)
    .maybeSingle();

  const balance = Number(balanceRow?.balance ?? 100000);
  if (balance < betAmount) {
    res.status(400).json({ error: "Insufficient balance" });
    return;
  }

  await supabase
    .from("game_balances")
    .upsert({ user_id: user.id, game_type: gameType, balance: balance - betAmount });

  const period = currentPeriod(gameType, parsedTypeId);
  const { data, error } = await supabase
    .from("game_bets")
    .insert({
      user_id: user.id,
      game_type: gameType,
      type_id: parsedTypeId,
      period_id: period.periodId,
      bet_type: betType,
      bet_value: String(betValue),
      amount: betAmount,
    })
    .select()
    .single();

  if (error) {
    res.status(500).json({ error: error.message });
    return;
  }
  res.status(201).json(toCamelCase(data));
});

router.put("/:gameType/settle", async (req, res): Promise<void> => {
  const typeId = parseTypeId(req.query["typeId"]);
  if (typeId == null) {
    res.status(400).json({ error: "Invalid typeId" });
    return;
  }
  const gameType = req.params.gameType as GameType;
  const period = currentPeriod(gameType, typeId);
  const result = rawResult(gameType, period.periodId);

  const { data: existing } = await supabase
    .from("game_results")
    .select("id")
    .eq("game_type", gameType)
    .eq("type_id", typeId)
    .eq("period_id", period.periodId)
    .maybeSingle();

  if (!existing) {
    const { error } = await supabase.from("game_results").insert({
      game_type: gameType,
      type_id: typeId,
      period_id: period.periodId,
      result,
      settled_at: new Date().toISOString(),
    });
    if (error) {
      res.status(500).json({ error: error.message });
      return;
    }
  }

  // Settle pending bets for this period
  const { data: pendingBets } = await supabase
    .from("game_bets")
    .select("*")
    .eq("game_type", gameType)
    .eq("type_id", typeId)
    .eq("period_id", period.periodId)
    .eq("status", "pending");

  for (const bet of pendingBets ?? []) {
    const { won, multiplier } = evaluateBet(gameType, bet.bet_type, bet.bet_value, result);
    const winAmount = won ? Number(bet.amount) * multiplier : 0;
    const status = won ? "won" : "lost";

    await supabase.from("game_bets").update({ status, win_amount: winAmount }).eq("id", bet.id);

    if (won) {
      const { data: bal } = await supabase
        .from("game_balances")
        .select("balance")
        .eq("user_id", bet.user_id)
        .eq("game_type", gameType)
        .maybeSingle();
      const currentBalance = Number(bal?.balance ?? 0);
      await supabase
        .from("game_balances")
        .upsert({ user_id: bet.user_id, game_type: gameType, balance: currentBalance + winAmount + Number(bet.amount) });
    }
  }

  res.json({ periodId: period.periodId, result });
});

export default router;
