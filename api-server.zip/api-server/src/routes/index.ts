import { Router, type IRouter } from "express";
import healthRouter from "./health";
import gamesRouter from "./games";
import { authMiddleware } from "../middleware/auth";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/games", authMiddleware, gamesRouter);

export default router;
