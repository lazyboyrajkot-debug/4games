import type { NextFunction, Request, Response } from "express";
import { supabase } from "../lib/supabase";

export type AuthedUser = { id: string; email: string | null };

declare global {
  namespace Express {
    interface Request {
      user?: AuthedUser;
    }
  }
}

export function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const header = req.header("authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  supabase.auth.getUser(token).then(({ data, error }: { data: { user: any | null }; error: any }) => {
    const user = data.user;
    if (error || !user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    req.user = { id: user.id, email: user.email ?? null };
    next();
  }).catch(() => {
    res.status(401).json({ error: "Unauthorized" });
  });
}
